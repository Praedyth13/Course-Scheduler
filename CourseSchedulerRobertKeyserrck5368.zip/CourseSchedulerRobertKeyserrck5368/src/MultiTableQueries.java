import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MultiTableQueries {
    private static Connection connection;
    private static PreparedStatement getAllClasses;
    private static PreparedStatement getAllClassDescriptions;
    private static PreparedStatement getScheduledStudentsByClass;
    private static PreparedStatement getWaitlistedStudentsByClass;
    private static PreparedStatement getStudentsByID;
    private static ResultSet resultSet;
    private static ResultSet secondSet;
    
    public static ArrayList<ClassDescription> getAllClassDescriptions(String semester){
        connection = DBConnection.getConnection();
        ArrayList<ClassDescription> descriptions = new ArrayList<>();
        
        try{
            getAllClasses = connection.prepareStatement("select coursecode, seats from classes where semester = ? order by coursecode");
            getAllClasses.setString(1, semester);
            resultSet = getAllClasses.executeQuery();
            
            while(resultSet.next()){
                String code = resultSet.getString("courseCode");
                int seats = resultSet.getInt("seats");
                
                getAllClassDescriptions = connection.prepareStatement("select description from courses where coursecode = ? order by coursecode");
                getAllClassDescriptions.setString(1, code);
                secondSet = getAllClassDescriptions.executeQuery();
                
                while(secondSet.next()){
                String title = secondSet.getString("description");
                ClassDescription description = new ClassDescription(code, title, seats);
                descriptions.add(description);
                }
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return descriptions;        
    }
    
    public static ArrayList<StudentEntry> getScheduledStudentsByClass(String semester, String code){
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<>();
        
        try{
            getScheduledStudentsByClass = connection.prepareStatement("select studentID from schedule where semester = ? and courseCode = ? and status = ? order by studentID");
            getScheduledStudentsByClass.setString(1, semester);
            getScheduledStudentsByClass.setString(2, code);
            getScheduledStudentsByClass.setString(3, "S");
            resultSet = getScheduledStudentsByClass.executeQuery();
            
            while(resultSet.next()){
                String ID = resultSet.getString("studentID");
                
                getStudentsByID = connection.prepareStatement("select firstName, lastName from students where studentID = ?");
                getStudentsByID.setString(1, ID);
                secondSet = getStudentsByID.executeQuery();
                
                while(secondSet.next()){
                String first = secondSet.getString("firstName");
                String last = secondSet.getString("lastName");
                StudentEntry student = new StudentEntry(ID, first, last);
                students.add(student);
                }
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return students;
    }
    
    public static ArrayList<StudentEntry> getWaitlistedStudentsByClass(String semester, String code){
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<>();
        
        try{
            getWaitlistedStudentsByClass = connection.prepareStatement("select studentID from schedule where semester = ? and courseCode = ? and status = ? order by timestamp");
            getWaitlistedStudentsByClass.setString(1, semester);
            getWaitlistedStudentsByClass.setString(2, code);
            getWaitlistedStudentsByClass.setString(3, "W");
            resultSet = getWaitlistedStudentsByClass.executeQuery();
            
            while(resultSet.next()){
                String ID = resultSet.getString("studentID");
                
                getStudentsByID = connection.prepareStatement("select firstName, lastName from students where studentID = ?");
                getStudentsByID.setString(1, ID);
                secondSet = getStudentsByID.executeQuery();
                
                while(secondSet.next()){
                String first = secondSet.getString("firstName");
                String last = secondSet.getString("lastName");
                StudentEntry student = new StudentEntry(ID, first, last);
                students.add(student);
                }
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return students;
    }
}
