
public class ClassDescription {
    private final String courseCode;
    private final String description;
    private final int seats;
    
    public ClassDescription(String code, String description, int seats){
        this.courseCode = code;
        this.description = description;
        this.seats = seats;
    } 
    
    public String getCourseCode(){
        return courseCode;
    }
    
    public String getDescription(){
        return description;
    }
    
    public int getSeats(){
        return seats;
    }
}