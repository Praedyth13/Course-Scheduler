
public class StudentEntry {
    private final String studentID;
    private final String firstName;
    private final String lastName;
    
    public StudentEntry(String ID, String first, String last){
        this.studentID = ID;
        this.firstName = first;
        this.lastName = last;
    }
    
    public String getStudentID(){
        return studentID;
    }
    
    public String getFirstName(){
        return firstName;
    }
    
    public String getLastName(){
        return lastName;
    }
    
    @Override
    public String toString() {
        return lastName + ", " + firstName + " " + studentID;
    }
}