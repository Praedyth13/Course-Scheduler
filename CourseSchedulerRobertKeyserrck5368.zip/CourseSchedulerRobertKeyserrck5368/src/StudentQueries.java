import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class StudentQueries {
    private static Connection connection;
    private static PreparedStatement addStudent;
    private static PreparedStatement dropStudent;
    private static PreparedStatement getStudent;
    private static PreparedStatement getAllStudents;
    private static ResultSet resultSet;
    
    public static void addStudent(StudentEntry student){
        String ID = student.getStudentID();
        String first = student.getFirstName();
        String last = student.getLastName();
        connection = DBConnection.getConnection();    
        
        try{
            addStudent = connection.prepareStatement("insert into students (StudentID, FirstName, LastName) values (?,?,?)");
            addStudent.setString(1, ID);
            addStudent.setString(2, first);
            addStudent.setString(3, last);
            addStudent.executeUpdate();
        }        
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }        
    }
    
    public static void dropStudent(String ID){
        connection = DBConnection.getConnection();    
        
        try{
            dropStudent = connection.prepareStatement("delete from students where studentID = ?");
            dropStudent.setString(1, ID);
            dropStudent.executeUpdate();
        }        
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
    }
    
    public static StudentEntry getStudent(String ID){
        connection = DBConnection.getConnection();
        StudentEntry student = null;
        
        try{
            getStudent = connection.prepareStatement("select firstName, lastName from students where studentID = ?");
            getStudent.setString(1, ID);
            resultSet = getStudent.executeQuery();
            
            String first = resultSet.getString("firstName");
            String last = resultSet.getString("lastName");
            student = new StudentEntry(ID, first, last); 
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return student;
    }
    
    public static ArrayList<StudentEntry> getAllStudents(){
        connection = DBConnection.getConnection();
        ArrayList<StudentEntry> students = new ArrayList<>();
        
        try{
            getAllStudents = connection.prepareStatement("select studentID, firstName, lastName from students order by studentID");
            resultSet = getAllStudents.executeQuery();
            
            while(resultSet.next()){
                String id = resultSet.getString("studentID");
                String first = resultSet.getString("firstName");
                String last = resultSet.getString("lastName");
                StudentEntry student = new StudentEntry(id, first, last);
                students.add(student);
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return students;        
    }
}