
import java.sql.Timestamp;

public class ScheduleEntry {
    private final String semester;
    private final String courseCode;
    private final String studentID;
    private final String status;
    private final Timestamp timestamp;
    
    
    public ScheduleEntry(String semester, String code, String ID, String status, Timestamp time){
        this.semester = semester;
        this.courseCode = code;
        this.studentID = ID;
        this.status = status;
        this.timestamp = time;
    }
    
    public String getSemester(){
        return semester;
    }
    
    public String getCourseCode(){
        return courseCode;
    }
    
    public String getStudentID(){
        return studentID;
    }
    
    public String getStatus(){
        return status;
    }
    
    public Timestamp getTimestamp(){
        return timestamp;
    }
}