import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class CourseQueries {
    private static Connection connection;
    private static PreparedStatement addCourse;
    private static PreparedStatement getAllCourseCodes;
    private static ResultSet resultSet;
    
    public static void addCourse(CourseEntry course){
        String code = course.getCourseCode();
        String description = course.getCourseDescription();        
        connection = DBConnection.getConnection();        
        
        try{
            addCourse = connection.prepareStatement("insert into courses (CourseCode, Description) values (?,?)");
            addCourse.setString(1, code);
            addCourse.setString(2, description);
            addCourse.executeUpdate();
        }        
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }        
    }
    
    public static ArrayList<String> getAllCourseCodes(){
        connection = DBConnection.getConnection();
        ArrayList<String> courseCodes = new ArrayList<>();
        
        try{
            getAllCourseCodes = connection.prepareStatement("select courseCode from courses order by CourseCode");
            resultSet = getAllCourseCodes.executeQuery();
            
            while(resultSet.next()){
                courseCodes.add(resultSet.getString("courseCode"));
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return courseCodes;        
    }
}