import java.sql.Timestamp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;

public class ScheduleQueries {
    private static Connection connection;
    private static PreparedStatement addSchedule;
    private static PreparedStatement dropStudentScheduleByCourse;
    private static PreparedStatement dropScheduleByCourse;
    private static PreparedStatement removeScheduleEntry;
    private static PreparedStatement replaceScheduleEntry;
    private static PreparedStatement getScheduleByStudent;
    private static PreparedStatement getScheduledStudentCount;
    private static PreparedStatement getWaitlistedStudentsByClass;
    private static ResultSet resultSet;
    
    public static void addScheduleEntry(ScheduleEntry entry){
        String semester = entry.getSemester();
        String code = entry.getCourseCode();
        String ID = entry.getStudentID();
        String status = entry.getStatus();
        Timestamp timestamp = entry.getTimestamp();        
        connection = DBConnection.getConnection(); 
        
        try{
            addSchedule = connection.prepareStatement("insert into schedule "
                                                        + "(Semester, courseCode, StudentID, status, timestamp)"
                                                        + " values (?,?,?,?,?)");
            addSchedule.setString(1, semester);
            addSchedule.setString(2, code);
            addSchedule.setString(3, ID);
            addSchedule.setString(4, status);
            addSchedule.setTimestamp(5, timestamp);
            addSchedule.executeUpdate();
        }        
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }        
    }
    
    public static void dropStudentScheduleByCourse(String semester, String code, String ID){
        connection = DBConnection.getConnection(); 
        
        try{
            dropStudentScheduleByCourse = connection.prepareStatement("delete from schedule "
                                                        + "where semester = ? and courseCode = ? and studentID = ?");
            dropStudentScheduleByCourse.setString(1, semester);
            dropStudentScheduleByCourse.setString(2, code);
            dropStudentScheduleByCourse.setString(3, ID);
            dropStudentScheduleByCourse.executeUpdate();
        }        
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
    }
    
    public static void dropScheduleByCourse(String semester, String code){
        connection = DBConnection.getConnection(); 
        
        try{
            dropScheduleByCourse = connection.prepareStatement("delete from schedule where semester = ? and courseCode = ?");
            dropScheduleByCourse.setString(1, semester);
            dropScheduleByCourse.setString(2, code);
            dropScheduleByCourse.executeUpdate();
        }        
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
    }
    
    public static void updateScheduleEntry(ScheduleEntry entry){
        String semester = entry.getSemester();
        String code = entry.getCourseCode();
        String ID = entry.getStudentID();
        java.sql.Timestamp timestamp = new java.sql.Timestamp(Calendar.getInstance().getTime().getTime());
        connection = DBConnection.getConnection(); 
        
        try{
            removeScheduleEntry = connection.prepareStatement("delete from schedule where semester = ? and courseCode = ? and studentID = ?");
            removeScheduleEntry.setString(1, semester);
            removeScheduleEntry.setString(2, code);
            removeScheduleEntry.setString(3, ID);
            removeScheduleEntry.executeUpdate();
        }        
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        
        ScheduleEntry newEntry = new ScheduleEntry(semester, code, ID, "S", timestamp);
        addScheduleEntry(newEntry);
    }
    
    public static ArrayList<ScheduleEntry> getScheduleByStudent(String semester, String studentID){
        connection = DBConnection.getConnection();
        ArrayList<ScheduleEntry> schedules = new ArrayList<>();
        
        try{
            getScheduleByStudent = connection.prepareStatement("select semester, courseCode, studentID, status, timestamp from schedule where semester = ? and studentID = ? order by courseCode");
            getScheduleByStudent.setString(1, semester);
            getScheduleByStudent.setString(2, studentID);            
            resultSet = getScheduleByStudent.executeQuery();
            
            while(resultSet.next()){
                String sem = resultSet.getString("semester");
                String courseCode = resultSet.getString("courseCode");
                String id = resultSet.getString("studentID");                
                String status = resultSet.getString("status");
                Timestamp timestamp = resultSet.getTimestamp("timestamp");
                ScheduleEntry schedule = new ScheduleEntry(sem, courseCode, id, status, timestamp);
                schedules.add(schedule);
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return schedules;        
    }
    
    public static int getScheduledStudentCount(String semester, String courseCode){
        connection = DBConnection.getConnection();
        int students = 0;
        
        try{
            getScheduledStudentCount = connection.prepareStatement("select studentID from schedule where semester = ? and courseCode = ? and status = ?");
            getScheduledStudentCount.setString(1, semester);
            getScheduledStudentCount.setString(2, courseCode);
            getScheduledStudentCount.setString(3, "S");
            resultSet = getScheduledStudentCount.executeQuery();
            
            while(resultSet.next()){
                students += 1;
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return students; 
    }    
    
    public static int getWaitlistedStudentsByClass(String semester, String code){
        connection = DBConnection.getConnection();
        int students = 0;
        
        try{
            getWaitlistedStudentsByClass = connection.prepareStatement("select studentID from schedule where semester = ? and courseCode = ? and status = ?");
            getWaitlistedStudentsByClass.setString(1, semester);
            getWaitlistedStudentsByClass.setString(2, code);
            getWaitlistedStudentsByClass.setString(3, "W");
            resultSet = getScheduledStudentCount.executeQuery();
            
            while(resultSet.next()){
                students += 1;
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return students;
    }
}