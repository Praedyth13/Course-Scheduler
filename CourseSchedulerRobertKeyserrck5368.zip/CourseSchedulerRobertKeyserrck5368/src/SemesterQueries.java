import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class SemesterQueries {
    private static Connection connection;
    private static PreparedStatement addSemester;
    private static PreparedStatement getSemesterList;
    private static ResultSet resultSet;
    
    public static void addSemester(String semester){
        connection = DBConnection.getConnection();  
        
        try{
            addSemester = connection.prepareStatement("insert into semester (semester) values (?)");
            addSemester.setString(1, semester);
            addSemester.executeUpdate();
        }        
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }        
    }
    
    public static ArrayList<String> getSemesterList(){
        connection = DBConnection.getConnection();
        ArrayList<String> semester = new ArrayList<>();
        
        try{
            getSemesterList = connection.prepareStatement("select semester from semester order by semester");
            resultSet = getSemesterList.executeQuery();
            
            while(resultSet.next()){
                semester.add(resultSet.getString("semester"));
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return semester;
        
    }
    
    
}
