

public class CourseEntry {
    private final String code;
    private final String description;
    
    public CourseEntry(String code, String description){
        this.code = code;
        this.description = description;
    }
    
    public String getCourseCode(){
        return code;
    }
    
    public String getCourseDescription(){
        return description;
    }
    
}
