import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ClassQueries {
    private static Connection connection;
    private static PreparedStatement addClass;
    private static PreparedStatement getAllCourseCodes;
    private static PreparedStatement getClassSeats;
    private static PreparedStatement dropClass;
    private static ResultSet resultSet;
    
    public static void addClass(ClassEntry classEntry){
        String code = classEntry.getCourseCode();
        String semester = classEntry.getSemester();
        int seats = classEntry.getSeats();       
        connection = DBConnection.getConnection();  
        
        try{
            addClass = connection.prepareStatement("insert into classes (Semester, CourseCode, seats) values (?,?,?)");
            addClass.setString(1, semester);
            addClass.setString(2, code);
            addClass.setInt(3, seats);
            addClass.executeUpdate();
        }        
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }        
    }
    
    public static void dropClass(String semester, String code){
        connection = DBConnection.getConnection();
        
        try{
            dropClass = connection.prepareStatement("delete from classes where semester = ? and coursecode = ?");
            dropClass.setString(1, semester);
            dropClass.setString(2, code);
            dropClass.executeUpdate();
        }        
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        } 
    }
    
    public static ArrayList<String> getAllCourseCodes(String semester){
        connection = DBConnection.getConnection();
        ArrayList<String> courseCodes = new ArrayList<>();
        
        try{
            getAllCourseCodes = connection.prepareStatement("select courseCode from classes where semester = ? order by CourseCode");
            getAllCourseCodes.setString(1, semester);
            resultSet = getAllCourseCodes.executeQuery();
            
            while(resultSet.next()){
                courseCodes.add(resultSet.getString(1));
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return courseCodes;        
    }
    
    public static int getClassSeats(String semester, String courseCode){
        connection = DBConnection.getConnection();
        int seats = 0;
        try{
            getClassSeats = connection.prepareStatement("select seats from classes where semester = ? and courseCode = ?");
            getClassSeats.setString(1, semester);
            getClassSeats.setString(2, courseCode);
            resultSet = getClassSeats.executeQuery();
            
            while(resultSet.next()){
               seats += resultSet.getInt("seats");
            }
        }
        catch(SQLException sqlException){
            sqlException.printStackTrace();
        }
        return seats; 
    }    
}
